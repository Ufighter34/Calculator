#include <iostream>
#include <string>
#include <cmath>
#include <cstring>
#include <vector>

std::string solving(std::string equation, std::vector<std::vector<std::string>>& operations, int count){
  //static int count;
  /*std::string operate = operations[count][0];
  std::cout<<operate;
  //std::cout<<'a';
  if(count>=1){
    return "a";
  }
  else{
    std::string answer = solving(equation, operations, count+1); 
    return answer;
  }*/
  if(count>=operations.size()){
    return equation;
  }
  else{
    std::string operate = operations[count][0];
    std::string operate2 = operations[count][1];
       //std::cout<<operate;
      if(equation.find(operate)!=std::string::npos||equation.find(operate2) != std::string::npos){
          //std::cout<<operations[0][count];
        int leftLocation = 0;
        int rightLocation = 0;
          //std::cout<<equation.find('.');
        int solution = 0;
        int left = 0;
        int right = 0;
        std::string currOperate = "";
        while(equation.find(operate) != std::string::npos || equation.find(operate2) != std::string::npos){ // Check if the operation is found
          if(equation.find(operate)>equation.find(operate2)){
            currOperate = operate2;
          }
          else{
            currOperate = operate;
          }
          if(equation.length()!=3){
            for(int i = equation.find(currOperate); i--, i>=0;){
              if(isdigit(equation[i])==0){
                leftLocation = i+1;
                left = stoi(equation.substr(i+1, equation.find(currOperate)-i-1));
                }
              else if(i==0){
                left = stoi(equation.substr(0, equation.find(currOperate)));
                }
              }
            for(int i = equation.find(currOperate); i<=equation.length(); i++){
              if(isdigit(equation[i])==0){
                //std::cout<<equation.substr(equation.find(operate)+1, i)+'\n';
                //right = 9;
                right = stoi(equation.substr(equation.find(currOperate)+1, i));
                rightLocation = equation.find(currOperate)+1;
                }
              else if(i==equation.length()){
                right = stoi(equation.substr(equation.find(currOperate)+1, i));
                }
              }
            }
          else{
            left = stoi(equation.substr(0, equation.find(currOperate)));
            right = stoi(equation.substr(equation.find(currOperate)+1, equation.length()));
              //std::cout<<equation.length()-(equation.find(operate)+1);
              //std::cout<<"\n";
            rightLocation = equation.find(currOperate)+1;
            }
          if(currOperate=="*"){
            solution = left*right;
            }
          else if(currOperate=="+"){
            solution = left+right;
            }
          else if(currOperate=="-"){
            solution = left-right;
            }
          else if(currOperate=="/"){
            solution = left/right;
          }
          int copyRight = right;
          int digits = 0;
          while(copyRight>0){
            copyRight/=10;
            digits++;
            }
          equation = equation.replace(leftLocation,rightLocation+digits, std::to_string(solution));
          }
          //operations.pop(0);
          //std::cout<<count;
          //operations.erase(operations.begin()); 
          //return solving(equation, operations, count+1);
        }
    return solving(equation, operations, count+1);
  }

  /*else{
    bool doesContain = false;
    for(int i = 0; i<equation.length(); i++){
      if(!(isdigit(equation[i]))){
        doesContain = true;
      }
    }
    if(doesContain){
      return solving(equation, operations, count+1);
    }
    else{
      return equation;
    }
  }*/
  return "";
}
int main() {
  std::string response = "";
  //std::string pemdas[][1] = {{"*"}, {"+"}};
  std::vector<std::vector<std::string>> pemdas = {{"*", "/"}, {"+", "-"}};
  //int index = 0;
  //int rows = sizeof(pemdas)/sizeof(pemdas[0]);
  //std::cout<<rows;
  while(true){
    std::cout<<"Please type your equation here:\n";
    std::cin>>response;
    if(response=="off"){
      break;
    }
    std::cout<<solving(response, pemdas, 0)+"\n";
    //std::cout<<solving(response, pemdas);
    //attempt 2
    /*for(int i = 0; i < rows; i++){
      for(int index = 0; index < response.length(); index++){
        if(response[index] == pemdas[i][0][0]){
          int endpoint = 0;
          for(int j = response.find(pemdas[i][0][0])+1; j<response.length(); j++){
            if(!(isdigit(response[j]))){
              endpoint = j;
              break;
            }
          }
          std::cout<<endpoint;
          std::string equationPart = response.substr(index-1, endpoint-index+1);
          if(endpoint!=0){
            equationPart = response.substr(index-1, endpoint);
          }
          else{
            equationPart = response;
          }
          //std::cout<<equationPart+"\n";
          std::string number1 = equationPart.substr(0, response.find(pemdas[i][0][0]));
          std::string sign = std::string(1, pemdas[i][0][0]);
          std::string number2 = equationPart.substr(response.find(pemdas[i][0][0])+1, equationPart.length());
          //std::cout<<sign+"\n";
          int solution = 0;
          if(sign=="*"){
            solution = stoi(number1)*stoi(number2);
          }
          else if(sign=="+"){
            solution = stoi(number1)+stoi(number2);
          }
          else if(sign=="-"){
            solution = stoi(number1)-stoi(number2);
          }
          else if(sign=="/"){
            solution = stoi(number1)/stoi(number2);
          }
          if(endpoint!=0){
            response = response.replace(index-1, endpoint, std::to_string(solution));
          }
          else{
            response = response.replace(0, response.length(), std::to_string(solution));
            std::cout<<response+"\n\n";
          }
          //std::cout<<std::to_string(solution)+"\n";
          //std::cout<<sign+"\n";
        }
      }
    }*/
    //attempt 1
    /*while(true){

      if(isdigit(response[index])){
        index++;
      }
      else{
        break;
      }   
    }
    std::string number1 = response.substr(0, index);
    std::string sign = response.substr(index, index);
    std::string number2 = response.substr(index+1, response.length());
    if((sign=="+")){
      int solution = stoi(number1)+stoi(number2);
      std::cout<<solution;
    }
    else if(sign=="-"){
      int solution = stoi(number1)-stoi(number2);
      std::cout<<solution;
    }
    else if(sign=="x" or sign=="*"){
      int solution = stoi(number1)*stoi(number2);
      std::cout<<solution;
    }
    else if(sign=="/"){
      int solution = stoi(number1)/stoi(number2);
      std::cout<<solution;
    }
    else if(sign=="%"){
      int solution = stoi(number1)%stoi(number2);
      std::cout<<solution;
    }
    else if(sign=="^"){
      int solution = pow(stoi(number1),stoi(number2));
      std::cout<<solution;

    std::cout<<"\n";
  */}

}